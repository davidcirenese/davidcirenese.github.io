Within this project is a movie.anim file with all the data needed to play the animation playable on start up.
Within the David'sMusicalMachine folder you can find an executable to run the software. From the bar at the top, properties
of the timeline can be edited, the moved can be played, and new animations can be created and saved.